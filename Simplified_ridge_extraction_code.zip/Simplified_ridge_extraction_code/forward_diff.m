function [fx_,fy_,fxx_,fyy_,fxy_,fxxx_,fyyy_,fxxy_,fyyx_] = forward_diff( map3d ,step ,H,W ,ori_in_new ,dx,dy)
%FORWARD_DIFF �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

% fy=diff(map3d)./step;
% fy0=zeros(1,W);
% % fy=[fy0;fy]; % 0�����ǰ���ں����һ�� ֻ�ǽ���������� ����������������
% fy=[fy;fy0];

% ��dx dy���� fx fy
% y=diff(map3d,1,1);
% x=diff(map3d,1,2);
% dy=[y;y(end,:)];
% dx=[x,x(:,end)];

fy=dx; 
% % fy(boundary_idx)=0;
fy1=zeros(size(map3d));
fy1(ori_in_new)=fy(ori_in_new);
% % fy_=fy(mainarea);
fy_=fy1(:);

% fx=diff(map3d,1,2)./step;
% fx0=zeros(H,1);
% % fx=[fx0,fx];
% fx=[fx,fx0];

fx=dy;
% % fx(boundary_idx)=0;
fx1=zeros(size(map3d));
fx1(ori_in_new)=fx(ori_in_new);
% % fx_=fx(mainarea);
fx_=fx1(:);
% 
% ori_in_new=mainarea;
% fy=diff(map3d)./step;
% fy0=zeros(1,W);
% % fy=[fy0;fy]; % 0�����ǰ���ں����һ�� ֻ�ǽ���������� ����������������
% fy=[fy;fy0];
% 
% fx=diff(map3d,1,2)./step;
% fx0=zeros(H,1);
% % fx=[fx0,fx];
% fx=[fx,fx0];
% 
% [new_fx,new_fy]=Correct_boundary_derivative(map_b,next_boundmap,mainmap,next_mainmap,fx,fy);
% 
% fy1=zeros(size(map3d));
% fy1(ori_in_new)=new_fy(ori_in_new);
% % % fy_=fy(mainarea);
% fy_=fy1(:);
% 
% % % fx(boundary_idx)=0;
% fx1=zeros(size(map3d));
% fx1(ori_in_new)=new_fx(ori_in_new);
% % % fx_=fx(mainarea);
% fx_=fx1(:);

fyy=diff(fy)./step;
fyy0=zeros(1,W);
% fyy=[fyy0;fyy];
fyy=[fyy;fyy0];
% % fyy(boundary_idx)=0;
fyy1=zeros(size(map3d));
fyy1(ori_in_new)=fyy(ori_in_new);
% % fyy_=fyy(mainarea);
fyy_=fyy1(:);

fxx=diff(fx,1,2)./step;
fxx0=zeros(H,1);
% fxx=[fxx0,fxx];
fxx=[fxx,fxx0];
% % fxx(boundary_idx)=0;
fxx1=zeros(size(map3d));
fxx1(ori_in_new)=fxx(ori_in_new);
% % fxx_=fxx(mainarea);
fxx_=fxx1(:);

fyx=diff(fy,1,2)./step;
fyx0=zeros(H,1);
% fyx=[fyx0,fyx];
fyx=[fyx,fyx0];
% % fyx(boundary_idx)=0;
fyx1=zeros(size(map3d));
fyx1(ori_in_new)=fyx(ori_in_new);
% % fyx_=fyx(mainarea);
fyx_=fyx1(:);

fxy=diff(fx)./step;
fxy0=zeros(1,W);
% fxy=[fxy0;fxy];
fxy=[fxy;fxy0];
% % fxy(boundary_idx)=0;
fxy1=zeros(size(map3d));
fxy1(ori_in_new)=fxy(ori_in_new);
% % fxy_=fxy(mainarea);
fxy_=fxy1(:);

fxyy=diff(fxy)./step;
fxyy0=zeros(1,W);
% fxyy=[fxyy0;fxyy];
fxyy=[fxyy;fxyy0];
% % fxyy(boundary_idx)=0;
fxyy1=zeros(size(map3d));
fxyy1(ori_in_new)=fxyy(ori_in_new);
% % fxyy_=fxyy(mainarea);
fxyy_=fxyy1(:);

fyyy=diff(fyy)./step;
fyyy0=zeros(1,W);
% fyyy=[fyyy0;fyyy];
fyyy=[fyyy;fyyy0];
% % fyyy(boundary_idx)=0;
fyyy1=zeros(size(map3d));
fyyy1(ori_in_new)=fyyy(ori_in_new);
% % fyyy_=fyyy(mainarea);
fyyy_=fyyy1(:);

fxxx=diff(fxx,1,2)./step;
fxxx0=zeros(H,1);
% fxxx=[fxxx0,fxxx];
fxxx=[fxxx,fxxx0];
% % fxxx(boundary_idx)=0;
fxxx1=zeros(size(map3d));
fxxx1(ori_in_new)=fxxx(ori_in_new);
% % fxxx_=fxxx(mainarea);
fxxx_=fxxx1(:);

fyxx=diff(fyx,1,2)./step;
fyxx0=zeros(H,1);
% fyxx=[fyxx0,fyxx];
fyxx=[fyxx,fyxx0];
% % fyxx(boundary_idx)=0;
fyxx1=zeros(size(map3d));
fyxx1(ori_in_new)=fyxx(ori_in_new);
% % fyxx_=fyxx(mainarea);
fyxx_=fyxx1(:);

fxxy=diff(fxx)./step;
fxxy0=zeros(1,W);
% fxxy=[fxxy0;fxxy];
fxxy=[fxxy;fxxy0];
% % fxxy(boundary_idx)=0;
fxxy1=zeros(size(map3d));
fxxy1(ori_in_new)=fxxy(ori_in_new);
% % fxxy_=fxxy(mainarea);
fxxy_=fxxy1(:);

fyyx=diff(fyy,1,2)./step;
fyyx0=zeros(H,1);
% fyyx=[fyyx0,fyyx];
fyyx=[fyyx,fyyx0];
% % fyyx(boundary_idx)=0;
fyyx1=zeros(size(map3d));
fyyx1(ori_in_new)=fyyx(ori_in_new);
% % fyyx_=fyyx(mainarea);
fyyx_=fyyx1(:);
end

