function [ fx,fy,fxx,fyy,fxy,fyxx,fxyy,fxxx,fyyy ] = Central_diff_test( map )
%CENTRAL_DIFF �������Ĳ����һ�׵���
% �����ڴ�����ʱ����ֱ���� xoy�����н��� �������� 1<=x<row 1<=y<=col ����uov����ԭ���xoyԭ���غ�
step=1;
map_xoy=map; %(i,j)
iandjcut1=[map_xoy(:,1),map_xoy(:,1:end-1)];% (i,j-1)
iandjadd1=[map_xoy(:,2:end),map_xoy(:,end)];% (i,j+1)

iadd1andj=[map_xoy(2:end,:);map_xoy(end,:)]; %(i+1,j)
icut1andj=[map_xoy(1,:);map_xoy(1:end-1,:)]; %(i-1,j)

icut1andjadd1=[map_xoy(1,:);map_xoy(1:end-1,1:end-1),map_xoy(1:end-1,end)]; %(i-1,j+1)
iadd1andjadd1=[map_xoy(2:end,2:end),map_xoy(2:end,end);map_xoy(end,:)]; % (i+1,j+1)

icut1andjcut1=[map_xoy(1,:);map_xoy(1:end-1,1),map_xoy(1:end-1,1:end-1)]; %(i-1,j-1)
iadd1andjcut1=[map_xoy(1:end-1,1),map_xoy(2:end,2:end);map_xoy(end,:)]; %(i+1,j-1)

iadd2andj=[map_xoy(3:end,:);map_xoy(end-1:end,:)]; %(i+2,j)
icut2andj=[map_xoy(1:2,:);map_xoy(1:end-2,:)];%(i-2,j)
iandjcut2=[map_xoy(:,1:2),map_xoy(:,1:end-2)];%(i,j-2)
iandjadd2=[map_xoy(:,3:end),map_xoy(:,end-1:end)];%(i,j+2)

fy=(iadd1andj-icut1andj)/2*step;
fx=(iandjadd1-iandjcut1)/2*step;                                                                      

fyy=iadd1andj-2*map_xoy+icut1andj;
fxx=iandjadd1-2*map_xoy+iandjcut1;

fxy=(iadd1andjadd1-icut1andjadd1-iadd1andjcut1+icut1andjcut1)/4;
fxxx=(iandjadd2-2*iandjadd1+2*iandjcut1-iandjcut2)/2;
fyyy=(iadd2andj-2*iadd1andj+2*icut1andj-icut2andj)/2;
fyxx=(iadd1andjadd1-2*iadd1andj+iadd1andjcut1-icut1andjadd1+2*icut1andj-icut1andjcut1)/2;
fxyy=(iadd1andjadd1-2*iandjadd1+icut1andjadd1-iadd1andjcut1+2*iandjcut1-icut1andjcut1)/2;
%���� ������dx ������dy

mu_x=zeros(3,3);mu_x(2,1)=0.5;mu_x(2,3)=0.5;
mu_y=zeros(3,3);mu_y(1,2)=0.5;mu_y(3,2)=0.5;
mu_xx=zeros(3,3);mu_xx(2,:)=[1,-2,1];
mu_yy=zeros(3,3);mu_yy(:,2)=[1,-2,1]';
mu_xy=zeros(3,3);mu_xy(1,1)=.25;mu_xy(1,3)=.25;mu_xy(3,1)=0.25;mu_xy(3,3)=0.25;
mu_yyy=zeros(5,5);mu_yyy(:,3)=[-0.5,1,0,-1,0.5]';
mu_xxx=zeros(5,5);mu_xxx(3,:)=[-0.5,1,0,-1,0.5];
mu_xyy=zeros(3,3);mu_xyy(:,1)=[-0.5,1,-0.5]';mu_xyy(:,3)=-[-0.5,1,-0.5]';
mu_yyx=zeros(3,3);mu_yyx(1,:)=[-0.5,1,-0.5];mu_yyx(3,:)=-[0.5,-1,0.5];
fx1=filter2(mu_x,map,'same');
fy1=filter2(mu_y,map,'same');
fxx1=filter2(mu_xx,map,'same');
fyy1=filter2(mu_yy,map,'same');
fxy1=filter2(mu_xy,map,'same');
fyyy1=filter2(mu_yyy,map,'same');
fxxx1=filter2(mu_xxx,map,'same');
fxyy1=filter2(mu_xyy,map,'same');
fyyx1=filter2(mu_yyx,map,'same');


end

