close all
clear
clc
img=imread('1.png');
figure;
imshow(img);
img_s=imfill(img);
cha=img_s-img;
jj=find(cha);
axis on
xlabel('x');
title('original');

dilate_img=Dilate_Area(img,3); %������
b1=fill_mini_hole(dilate_img);
b2=fill_two_space(b1);
b3=fill_mini_hole(b2);
[boundary,bmap]=New_Boundary_Search_exter(b3,8);

figure;
imshow(bmap);
axis on 
title('diated boundary');

