% ----------Gao Fengyi------------%
% mainarea is an N*1 matrix denotes the area is 1 ,and the map is a matrix M*N denotes the whole picture(include 0 and 1)
% K is a constant which notes the method is 4 neighbors search or 8 neighbors search
% Boundary  is a Q*2 matrix denotes the edges position
% boundarymap where the boundary is 1 and the other area is 0
function [Boundary,boundarymap]=boundary_search(mainarea_ind,map,K)

[H,W]=size(map);
[mainarea_x,mainarea_y]=ind2sub(size(map),mainarea_ind); %
mainarea=cat(2,mainarea_x,mainarea_y);

e1=mainarea(:,1)==0;
e2=mainarea(:,1)==H;
e3=mainarea(:,2)==0;
e4=mainarea(:,2)==W;

edge_valid=( mainarea(:,1)==0 )| (mainarea(:,1)==H)|(mainarea(:,2)==0)|(mainarea(:,2)==W);
edge=mainarea(find(edge_valid~=0)); % edge includes the point in the edge of the picture

		top_x=mainarea(:,1)-1;
        top_y=mainarea(:,2); %top point index
		invalid_top=top_x<1;
		top_x(invalid_top)=1; % edge point neighbors processing
		
		
		bottom_x=mainarea(:,1)+1;
		bottom_y=mainarea(:,2); %bottom point index
		bottom_invalid=bottom_x>H;
		bottom_x(bottom_invalid)=H;
        
		left_x=mainarea(:,1);
		left_y=mainarea(:,2)-1; % left
		left_invalid=left_y<1;
		left_y(left_invalid)=1;
		
		right_x=mainarea(:,1);
		right_y=mainarea(:,2)+1; %right
		right_invalid=right_y>W;
		right_y(right_invalid)=W;
		
	switch K
        
		case 4
		fprintf('4 neighbors search!\n')
        
        top_ind=sub2ind(size(map),top_x,top_y);
        bottom_ind=sub2ind(size(map),bottom_x,bottom_y);
        left_ind=sub2ind(size(map),left_x,left_y);
        right_ind=sub2ind( size(map),right_x,right_y);
        
		valid=( map(top_ind)==0 | map(bottom_ind)==0 | map(left_ind)==0 | map(right_ind)==0);
		
		boundary=mainarea_ind(find(valid~=0)); %ͼ�����һȦ 
        Boundary=[edge;boundary];
        
		case 8
		fprintf('8 neighbors search!\n')
		
		left_up_x=mainarea(:,1)-1;
		left_up_y=mainarea(:,2)-1;
		
		left_up_invalidx=left_up_x<1 ;
		left_up_x(left_up_invalidx)=1;
		left_up_invalidy=left_up_y<1;
		left_up_y(left_up_invalidy)=1; %left up
		
		left_down_x=mainarea(:,1)+1;
		left_down_y=mainarea(:,2)-1;
		
		left_down_invalidx=left_down_x>H;
		left_down_x(left_down_invalidx)=H;
		left_down_invalidy=left_down_y<1;
		left_down_y(left_down_invalidy)=1; %left down
		
		right_up_x=mainarea(:,1)-1;
		right_up_y=mainarea(:,2)+1;
		
		righ_up_invalidx=right_up_x<1;
		right_up_x(righ_up_invalidx)=1;
		righ_up_invalidy=right_up_y>W;
		right_up_y(righ_up_invalidy)=W; %right up
		
		right_down_x=mainarea(:,1)+1;
		right_down_y=mainarea(:,2)+1;
		
		right_down_invalidx=right_up_x>H;
		right_down_x(right_down_invalidx)=H;
		right_down_invalidy=right_down_y>W;
		right_down_y(right_down_invalidy)=W; %right down
		% abc=find(map(top_x,top_y)==0);
        
        top_ind=sub2ind(size(map),top_x,top_y);
        bottom_ind=sub2ind(size(map),bottom_x,bottom_y);
        left_ind=sub2ind(size(map),left_x,left_y);
        right_ind=sub2ind( size(map),right_x,right_y);
        left_down_ind=sub2ind(size(map),left_down_x,left_down_y);
        right_down_ind=sub2ind(size(map),right_down_x,right_down_y);
        left_up_ind=sub2ind(size(map),left_up_x,left_up_y);
        right_up_ind=sub2ind(size(map),right_up_x,right_up_y);
        % ˫����ĳɵ�����
		valid=( map(top_ind)==0 | map(bottom_ind)==0 | map(left_ind)==0 | map(right_ind)==0 | ...
		  map(left_up_ind)==0 | map(left_down_ind)==0 | map(right_down_ind)==0 | map(right_up_ind)==0 );
		boundary=mainarea_ind(find(valid~=0)); %ͼ�����һȦ 
        Boundary=[edge;boundary];
        
%         imshow(imgtest);
		
        otherwise
		  error('error parameter!\n')

	end %switch
    
        imgtest=zeros(size(map));
        imgtest(boundary)=1;
        boundarymap=imgtest;
        figure;
        imshow(boundarymap);
        title('original');
        [boundary_x,boundary_y]=ind2sub(size(map),boundary);
        boundary_sub=cat(2,boundary_x,boundary_y);
        new_boundary=Cancel_zigzag(boundary_sub,boundarymap);
        finalmap=zeros(size(map));
        finalmap(new_boundary)=1;
        figure;
        imshow(finalmap);
        title('without zigzag');
end % function