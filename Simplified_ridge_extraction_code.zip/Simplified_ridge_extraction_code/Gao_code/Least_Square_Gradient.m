function [dx,dy] = Least_Square_Gradient( map3d ) %��һ���ݶ�
% ����С���˼���ÿ�����һ�׵���
 [h,w]=size(map3d);
 step=1;
orient=[-step,-step;-step,0;-step,step;0,-step;0,0;0,step;step,-step;step,0;step,step]; %�������Լ�����

orient_up=[0,-step;0,0;0,step;step,-step;step,0;step,step];

orient_left=[-step,0;-step,step;0,0;0,step;step,0;step,step];

orient_down=[-step,-step;-step,0;-step,step;0,-step;0,0;0,step];

orient_right=[-step,-step;-step,0;0,-step;0,0;step,-step;step,0];

orient11=[0,0;0,step;step,0;step,step] ;

orient1w=[0,-step;0,0;step,-step;step,0];

orienth1=[-step,0;-step,step;0,0;0,step];

orienthw=[-step,-step;-step,0;0,-step;0,0];

d=[];
disp('is computing the dx dy!');
 for j=1:w %��
     for i=1:h %��
%          fprintf('i=%d,j=%d\n',i,j);
        if i==1 && j==1
            cur_orient=orient11;
        elseif i==1 &&j==w
            cur_orient=orient1w;
        elseif i==h && j==1
            cur_orient=orienth1;
        elseif i==h && j==w
            cur_orient=orienthw;
        elseif i==1 && j~=1 && j~=w
            cur_orient=orient_up;
        elseif i==h &&j~=1 && j~=w
            cur_orient=orient_down;
        elseif j==1 && i~=1 && i~=h
            cur_orient=orient_left;
        elseif j==w && i~=1 && i~=h
            cur_orient=orient_right;
        else
            cur_orient=orient;
        end
        
        neighs=repmat([i,j],size(cur_orient,1),1)+cur_orient;
        z=ones(size(cur_orient,1),1);
        A=[neighs,z];
        f=map3d(sub2ind(size(map3d),neighs(:,1),neighs(:,2)));
        abc=(A'*A)\(A'*f); %inv(A'*A)*(A'*b);
        d=[d;abc(1),abc(2)];
     end
 end

 dx=reshape(d(:,1),[h,w]);
 dy=reshape(d(:,2),[h,w]);
end

