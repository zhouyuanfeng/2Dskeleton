function [ Boundary, boundarymap ] = New_Boundary_Search_inner( map ,K)
% mainarea denotes the area of the salient area value is 1 in map
% Boundary denotes the index of the boundary area
% boundarymap denotes the map of generating boundary

% this function aims at search the inner boundary  instead of the boundary
% out of the boundary out the mainarea
Boundary=[];
switch K
    case 4
        direction=[-1,0;0,-1;1,0;0,1];
    case 8
    direction=[-1 -1;0 -1;1 -1;1 0;1 1;0 1;-1 1;-1 0];
end


% [mainarea_x,mainarea_y]=ind2sub(size(map),mainarea);
[row,col]=size(map);
for ii=1:row
    if map(ii,1)==1
        Boundary=[Boundary;[ii,1]];
    end
    if map(ii,col)==1
        Boundary=[Boundary;[ii,col]];
    end
end
for jj=1:col
    if map(1,jj)==1
        Boundary=[Boundary;[1,jj]];
    end
    if map(row,jj)==1
        Boundary=[Boundary;[row,jj]];
    end
end

%�߽絥������
for i=2:row-1
    for j=2:col-1
         label=false;
         cur=[i,j];
        for k=1:K
          neigh=[cur(1)+direction(k,1),cur(2)+direction(k,2)];
          if map(neigh(1),neigh(2))==0
              label_neigh=true;
              break;
          else
              label_neigh=false;
          end
            
        end
        lab=label||label_neigh;
        
        if map(i,j)==1 && lab
            Boundary=[Boundary;[i,j]];
        end
        
    end
end
ind_bound=sub2ind(size(map),Boundary(:,1),Boundary(:,2));
boundarym=zeros(size(map));
boundarym(ind_bound)=1;
boundarymap=boundarym;
figure;
imshow(boundarymap);
new_boundary=Cancel_zigzag(Boundary,boundarymap);

% show new boundary
newbound=zeros(size(map));
ind_newbound=sub2ind(size(map),new_boundary(:,1),new_boundary(:,2));
newbound(ind_newbound)=1;
figure;
imshow(newbound);
end %function

