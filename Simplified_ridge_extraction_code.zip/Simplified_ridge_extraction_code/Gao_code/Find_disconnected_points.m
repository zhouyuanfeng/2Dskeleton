function [ new_ridgemap ] = Find_disconnected_points( new_ridges,H,W,threshold ,map3d,direct,objmap,name)
%FIND_DISCONNECTED_POINTS �˴���ʾ�йش˺�����ժҪ
%   threshold �����ض�һЩС�ķ�֧��Ӧ�ļ���
% sign=true(size(new_ridges,1),1);
ridgemap=zeros(H,W);

%% ���������� �����õ��Ļ����ǵ����صĹǼ�ͼ
inter_ridge=round(new_ridges);

if isempty(inter_ridge)
    disp('none ridges');
else
    inter_ridge_ind=sub2ind([H,W],inter_ridge(:,1),inter_ridge(:,2));
try
    
   ridgemap(inter_ridge_ind)=1;
catch
   disp('wrong in find disconnected points') ;
end
%%  
        disconnected_uv=[];
        disconnected=[];
        neigh8=[0,-1;0,1;1,0;1,1;1,-1;-1,0;-1,1;-1,-1];
        %% ȥ��� ����ĵ����صĲ���Ҫȥ�����
%         tmp_ridgemap=zeros(size(ridgemap));
%         tmp_ind=find(ridgemap);
%         [tmp_u,tmp_v]=ind2sub(size(ridgemap),tmp_ind);
%         tmp_sub=Cancel_zigzag([tmp_u,tmp_v],ridgemap); 
%         tmp_ind=sub2ind(size(ridgemap),tmp_sub(:,1),tmp_sub(:,2));
%         tmp_ridgemap(tmp_ind)=1;
        [L,num]=bwlabel(ridgemap,8);
           for j=1:num
               if num==1
                   break;
               end
              cur_j=find(L==j);
              if size(cur_j,1)<=threshold
                 ridgemap(cur_j)=0; 
              end
           end
        %%
        thin_ridgemap=bwmorph(ridgemap,'thin');
        thin_inter_ridge_ind=find(thin_ridgemap);
        [thin_u,thin_v]=ind2sub(size(thin_ridgemap),thin_inter_ridge_ind);
        for i=1:size(thin_inter_ridge_ind,1)
            cur=[thin_u(i),thin_v(i)];
            cur_neigh=repmat(cur,size(neigh8,1),1)+neigh8;
            s=cur_neigh(:,1)<1 |cur_neigh(:,1)>H |cur_neigh(:,2)<1 |cur_neigh(:,2)>W ;
            cur_neigh(s,:)=[];
            cur_neigh_ind=sub2ind([H,W],cur_neigh(:,1),cur_neigh(:,2));
            iii=find(thin_ridgemap(cur_neigh_ind));
            if size(iii,1)<=1
                disconnected_uv=[disconnected_uv;cur];
            end
                
        end
         old_ind=find(ridgemap);
         
      %% ��ͷ��ͼ
%       d_pic=(ones(H,W,3));
%      
%       obj_ind=find(objmap);
%       d_pic(obj_ind)=0;
%       d_pic(obj_ind+H*W)=0;
%       d_pic(obj_ind+2*H*W)=0;
%       
%        d_pic(old_ind)=1;
%       d_pic(old_ind+H*W)=1;
%       d_pic(old_ind+2*H*W)=1;
%       
%       
%       disconnected_ind=sub2ind([H,W],disconnected_uv(:,1),disconnected_uv(:,2));
%       d_pic(disconnected_ind)=0;
%       d_pic(disconnected_ind+H*W)=1;
%       d_pic(disconnected_ind+2*H*W)=0;
%       figure;imshow(d_pic);title('disconnected pixels');
%       
%       r_d=zeros(H,W,3);
%       r_d(old_ind)=1;
%       r_d(old_ind+H*W)=1;
%       r_d(old_ind+2*H*W)=1;
%       r_d(disconnected_ind)=0;
%       r_d(disconnected_ind+H*W)=1;
%       r_d(disconnected_ind+2*H*W)=0;
%       figure;imshow(r_d);title('disconnected dd');
%%
  [new_ridgemap]= trace(disconnected,disconnected_uv,map3d,ridgemap,direct);
 %% ��ͼ1
%   figure;imshow(ridgemap);
%   title('ridgemap');
%   
%    new_ind=find(new_ridgemap);
%    diff_ind=setdiff(new_ind,old_ind);
%    color_ridge=uint8(zeros(H,W,3));
%    color_ridge(old_ind)=255;
%    color_ridge(old_ind+H*W)=255;
%    color_ridge(old_ind+2*H*W)=255;
%    color_ridge(diff_ind)=255;
%    color_ridge(diff_ind+H*W)=0;
%    color_ridge(diff_ind+2*H*W)=0;
%    figure;imshow(color_ridge);
%    
%    rr1=reconstruct(ridgemap,objmap);
%    rr2=reconstruct(new_ridgemap,objmap);
%    
%    dd_pic=ones(H,W);
%    dd_pic(logical(objmap))=0;
%    dd_pic(new_ind)=1;
%    figure;imshow(dd_pic);
%    result_p='result/';
%    path=strcat([result_p,name],'.png');
%    imwrite(dd_pic,path);
end
end

function [new_ridgemap]=trace(disconnected,disconnected_uv,map3d,ridgemap,direct)

    % �Ӷ�ͷ��ʼtrace
    pixel=true;
    new_ridgemap=ridgemap;
    
    [H,W]=size(ridgemap);
    neigh8=[-1,-1;-1,0;-1,1;0,-1;0,1;1,-1;1,0;1,1];
    ridgemap_l=logical(ridgemap);
    if pixel % ʹ������trace 8����Ƚϴ�С
        for i=1:size(disconnected_uv,1)
            cur=disconnected_uv(i,:);
            while(1)
            cur_neigh=repmat(cur,size(neigh8,1),1)+neigh8;
            ind=cur_neigh(:,1)<1 | cur_neigh(:,1)>H |cur_neigh(:,2)<1 |cur_neigh(:,2)>W;
            if any(ind)
                cur_neigh(ind,:)=[];
            end
            cur_neigh_ind=sub2ind(size(ridgemap),cur_neigh(:,1),cur_neigh(:,2));
            cur_neigh_value=map3d(cur_neigh_ind);
            [~,max_ind]=max(cur_neigh_value);
             if ridgemap_l(cur_neigh_ind(max_ind))
                break;
            end  %�����б�ǵ� ��Ϊ��ײ
            new_ridgemap(cur_neigh_ind(max_ind))=1;
            ridgemap_l(cur_neigh_ind(max_ind))=true;
            cur=cur_neigh(max_ind,:);
            end
        end
    else %������trace �����ݶȷ���
        trace_direct=[-1,-1;-1,0;-1,1;0,-1;0,1;1,-1;1,0;1,1];
        trace_direct=trace_direct./repmat(sqrt(sum(trace_direct.^2,2)),1,size(trace_direct,2));
        for i=1:size(disconnected_uv,1)
            cur=disconnected_uv(i,:);
            while(1)
                cur_ind=sub2ind(size(ridgemap),cur(1),cur(2));
                cur_direct=direct(cur_ind,:);
                cur_neigh=repmat(cur,size(neigh8,1),1)+neigh8;
                ind=cur_neigh(:,1)<1 | cur_neigh(:,1)>H |cur_neigh(:,2)<1 |cur_neigh(:,2)>W;
                if any(ind)
                    cur_neigh(ind,:)=[];
                end
                cur_neigh_ind=sub2ind(size(ridgemap),cur_neigh(:,1),cur_neigh(:,2));
               
                 dai_direct=trace_direct(~ind,:);
                 dai_neigh=cur_neigh(~ind,:);
                 direct_value=dai_direct*cur_direct';
                 [~,l]=max(direct_value);
                 next_loc=dai_neigh(l,:);
                  if ridgemap_l(next_loc(1),next_loc(2))
                    break;
                  end
                 new_ridgemap(next_loc(1),next_loc(2))=1;
                 ridgemap_l(next_loc(1),next_loc(2))=true;
                 cur=next_loc;
            end
            
        end
        
    end

end


function[dai_uv,dai]=find_d(new_ridges,H,W)
%% �����Ͻǵ���������ʾ  �Ҿ����е㲻̫�� ���־�� ���ȳ���1
ridgemap=zeros(H,W);
dai=[];dai_uv=[];
for i=1:H-1
    for j=1:W-1
       ind= find(new_ridges(:,1)>=i & new_ridges(:,1)<=i+1 & new_ridges(:,2)>=j & new_ridges(:,2)<=j+1);
       if ~isempty(ind)
           if size(ind,1)==1
               dai=[dai;new_ridges(ind,:)];
               dai_uv=[dai_uv;i,j];
           end
%            if  any(sign(ind))
%               ridgemap(i,j)=1; 
%               sign(ind)=false;
%            end
            ridgemap(i,j)=1; %���Ͻǵ�����
       end
       
    end
end
        L=bwlabel(ridgemap,8);
        remove_k=[];
        for k=1:size(dai,1)
            cur_uv=dai_uv(k,:);
            cur_id=L(cur_uv(1),cur_uv(2));
            cur_id_ind=find(L==cur_id);
            if size(cur_id_ind,1)<=threshold
                dai_ind=sub2ind(size(ridgemap),dai_uv(:,1),dai_uv(:,2));
                dai_index=L(dai_ind);
                ii=find(dai_index==cur_id);
                ridgemap(cur_id_ind)=0;
                if ~isempty(ii)
                   remove_k=[k;ii];
                end
             
            end
        end
           dai_uv(remove_k,:)=[];
           dai(remove_k,:)=[];

end