clear
clc
close all
h=250;w=250;
map=zeros(h,w);
map(1,:)=1;
map(end,:)=1;
map(:,1)=1;
map(:,end)=1;
idx=find(map);
[subx,suby]=ind2sub([h,w],idx);

idx_inner=find(map~=1);
[inner_x,inner_y]=ind2sub([h,w],idx_inner);

newmap=zeros(h,w);
newmap(idx)=0;
for i=1:length(inner_x)
    
    current=[inner_x(i),inner_y(i)];
    bound=[subx,suby];
    d=bound-repmat(current,[size(idx,1),1]);
    dist=sqrt( sum(d.^2,2) );
    [distance,I]=min(dist);
    newmap(inner_x(i),inner_y(i))=distance;
    
end

x=1:1:h;
y=1:1:w;
[X,Y]=meshgrid(x,y);
figure;
mesh(X',Y',newmap);
axis on
axis equal
title('distance show');


