% % -------Gao fengyi-----% %
function [ ridgepoint1 ,R_map1 ,ridgepoint2, R_map2] = Correct_direction( direct_max,direct_min,K,P,fx,fy,fxx,fxy,fyy,fxxx,fyyy,fxxy,fxyy,H,W,objmap)
% input
%   direct_max direct_min �ֱ��ʾ������������С������
%   K ��ʾn*2������ֵ
%   P ��ʾ2*2*n����������
%   H /W��ʾͼ��� �� /��
%   ����ľ���ʾƫ����
ridgepoint1=[];
ridgepoint2=[];
R_map1=zeros(H,W);
R_map2=zeros(H,W);
disp('correct direction and compute ridge points');
for i=1:H-1     %�ȴ�������ı�
   for j=1:W-1
       ind1=sub2ind([H,W],i,j);
       ind2=sub2ind([H,W],i,j+1);
       if  objmap(i,j)==1 && objmap(i,j+1)==1
           cor=[i,j;i,j+1]; % ��¼��ǰ�������������ƽ������ ��Zֵ��Ӧ��R

           d1=direct_max(ind1,:);
           d2=direct_max(ind2,:);
           d1_min=direct_min(ind1,:);
           d2_min=direct_min(ind2,:);
           fx_=[fx(ind1);fx(ind2)];
           fy_=[fy(ind1);fy(ind2)];
           fxx_=[fxx(ind1);fxx(ind2)];
           fxy_=[fxy(ind1);fxy(ind2)];
           fyy_=[fyy(ind1);fyy(ind2)];
           fxxx_=[fxxx(ind1);fxxx(ind2)];
           fyyy_=[fyyy(ind1);fyyy(ind2)];
           fxxy_=[fxxy(ind1);fxxy(ind2)];
           fxyy_=[fxyy(ind1);fxyy(ind2)];

           k_two_max=[K(ind1,1);K(ind2,1)]; 
           k_two_min=[K(ind1,2);K(ind2,2)];
           % t=P(:,1,ind1);% test
           if(d1*d2'<0)
              p_two_max=[P(:,1,ind1),-P(:,1,ind2)]; %��������ʶ�Ӧ��
           else
               p_two_max=[P(:,1,ind1),P(:,1,ind2)];
           end

           if (d1_min*d2_min'<0)
               p_two_min=[P(:,2,ind1),-P(:,2,ind2)];
           else
               p_two_min=[P(:,2,ind1),P(:,2,ind2)];
           end
           R_max=compute_R(k_two_max,p_two_max,fx_,fy_,fxx_,fxy_,fyy_,fxxx_,fyyy_,fxxy_,fxyy_);
           R_map1(ind1)=R_max(1);
           R_map1(ind2)=R_max(2);
           point=compute_ridgepoint(cor,R_max);
           R_min=compute_R(k_two_min,p_two_min,fx_,fy_,fxx_,fxy_,fyy_,fxxx_,fyyy_,fxxy_,fxyy_);
           R_map2(ind1)=R_min(1);
           R_map2(ind2)=R_min(2);
           point_min=compute_ridgepoint(cor,R_min);
           if ~isempty(point)
              ridgepoint1=[ridgepoint1;point]; 
           end
           if ~isempty(point_min)
              ridgepoint2=[ridgepoint2;point_min] ;
           end
       end
       
       %�����������ı�
       if objmap(i,j)==1 && objmap(i+1,j)==1
           
           ind1v=sub2ind([H,W],i,j);
           ind2v=sub2ind([H,W],i+1,j);
           corv=[i,j;i+1,j]; % ��¼��ǰ�������������ƽ������ ��Zֵ��Ӧ��R

           d1=direct_max(ind1v,:);
           d2=direct_max(ind2v,:);
           d1_min=direct_min(ind1v,:);
           d2_min=direct_min(ind1v,:);

           fx_=[fx(ind1v);fx(ind2v)];
           fy_=[fy(ind1v);fy(ind2v)];
           fxx_=[fxx(ind1v);fxx(ind2v)];
           fxy_=[fxy(ind1v);fxy(ind2v)];
           fyy_=[fyy(ind1v);fyy(ind2v)];
           fxxx_=[fxxx(ind1v);fxxx(ind2v)];
           fyyy_=[fyyy(ind1v);fyyy(ind2v)];
           fxxy_=[fxxy(ind1v);fxxy(ind2v)];
           fxyy_=[fxyy(ind1v);fxyy(ind2v)];

           k_two_max=[K(ind1v,1);K(ind2v,1)]; 
           k_two_min=[K(ind1v,2);K(ind2v,2)];
           if(d1*d2'<0)
              p_two_max=[P(:,1,ind1v),-P(:,1,ind2v)]; %��������ʶ�Ӧ��
           else
               p_two_max=[P(:,1,ind1v),P(:,1,ind2v)];
           end
           if(d1_min*d2_min'<0)
               p_two_min=[P(:,2,ind1v),-P(:,2,ind2v)];
           else
               p_two_min=[P(:,2,ind1v),P(:,2,ind2v)];
           end
           R=compute_R(k_two_max,p_two_max,fx_,fy_,fxx_,fxy_,fyy_,fxxx_,fyyy_,fxxy_,fxyy_);
           R_map1(ind1v)=R(1);
           R_map1(ind2v)=R(2);
           point=compute_ridgepoint(corv,R);
           if ~isempty(point)
              ridgepoint1=[ridgepoint1;point]; 
           end

           R_min=compute_R(k_two_min,p_two_min,fx_,fy_,fxx_,fxy_,fyy_,fxxx_,fyyy_,fxxy_,fxyy_);
           R_map2(ind1v)=R_min(1);
           R_map2(ind2v)=R_min(2);
           point_min=compute_ridgepoint(corv,R_min);
           if ~isempty(point_min)
               ridgepoint2=[ridgepoint2;point_min];
           end
  
       
       end
   end 
   
end


end

function R=compute_R(K_two,P_two,fx,fy,fxx,fxy,fyy,fxxx,fyyy,fxxy,fxyy)

p1=P_two(1,:);
p2=P_two(2,:);
p1=p1(:);
p2=p2(:);
t1=p1.^3;
t2=(p1.^2).*p2;
t3=p1.*(p2.^2);
t4=p2.^3;
t5=p1.^2;
t6=p1.*p2;
t7=p2.^2;
t8=p1;
t9=p2;

k=K_two;

R=(t1.*fxxx+(3*t2).*fxxy+(3*t3).*fxyy+t4.*fyyy)-3*sqrt(ones(size(fx))...
   + fx.*fx + fy.*fy).* (t5.*fxx+(2*t6).*fxy + t7.*fyy) .*( t8.*fx+t9 .*fy ).*k ;

end

function point=compute_ridgepoint(cor,R) 
% ��������ʦ˵�ķֱ�����0��
point=[];
if(R(1)*R(2)<0 || R(1)*R(2)==0)
    rate=abs(R(1))./abs(R(1)-R(2));
    a=[cor(1,:),R(1)];
    b=[cor(2,:),R(2)];
    ab=b-a;
    point=rate*ab+a;
end

end