function [ Boundary, boundarymap ] = New_Boundary_Search_exter( map ,K)
% mainarea denotes the area of the salient area value is 1 in map 
% map  is a binary map  K is the to choose K neighbor 
% Boundary denotes the index of the boundary area
% boundarymap denotes the map of generating boundary

% this function aims at search the external boundary  
Boundary=[];
switch K
    case 4
        direction=[-1,0;0,-1;1,0;0,1];
    case 8
    direction=[-1 -1;0 -1;1 -1;1 0;1 1;0 1;-1 1;-1 0];
end


% [mainarea_x,mainarea_y]=ind2sub(size(map),mainarea);
[row,col]=size(map);
%֮ǰ�ǵ��������߽磬ֱ�Ӽ��뵽�߽缯 ����������Ҫ��ȡ������߽磬������Ҫ��������Ȧ
% for ii=1:row
%     if map(ii,1)==1
%         Boundary=[Boundary;[ii,1]];
%     end
%     if map(ii,col)==1
%         Boundary=[Boundary;[ii,col]];
%     end
% end
% for jj=1:col
%     if map(1,jj)==1
%         Boundary=[Boundary;[1,jj]];
%     end
%     if map(row,jj)==1
%         Boundary=[Boundary;[row,jj]];
%     end
% end

%�߽絥������
for i=1:row
    for j=1:col
         label=false;
         cur=[i,j];
         
         if i==1||i==row||j==1||j==col
             if map(i,j)==1 %������������ͼ��߽����
                Boundary=[Boundary;[i,j]];
             else
                 for k=1:K
                     neigh=[cur(1)+direction(k,1),cur(2)+direction(k,2)];
                     wuxiao_ind=find(neigh(:,1)==0||neigh(:,1)==row+1||neigh(:,2)==0||neigh(:,2)==col+1);
                     % [wuxiao_x,~]=ind2sub(size(neigh),wuxiao_ind);
                    % neigh(wuxiao_x)=[];
                    label_neigh=false;
                    if isempty(wuxiao_ind)
                       if map(neigh(1),neigh(2))==1
                           label_neigh=true;
                           break;
                       end
                    else
                        continue;
                    end
                 end
                 lab=label||label_neigh;
             end
             
         else
             for k=1:K
                  neigh=[cur(1)+direction(k,1),cur(2)+direction(k,2)];
                  if map(neigh(1),neigh(2))==1
                      label_neigh=true;
                      break;
                  else
                      label_neigh=false;
                  end
             end
               lab=label||label_neigh;
         end
      
        
        if map(i,j)==0 && lab
            Boundary=[Boundary;[i,j]];
        end
        
    end
end
Boundary=unique(Boundary,'rows'); %���ܺͿ�ʼ�����ű߽�ĵ����ظ�
ind_bound=sub2ind(size(map),Boundary(:,1),Boundary(:,2));
boundarym=zeros(size(map));
boundarym(ind_bound)=1;
boundarymap1=boundarym;
% figure;
% imshow(boundarymap1);
% title('with zigzag');
new_boundary=Cancel_zigzag(Boundary,boundarymap1);

% show new boundary
newbound=zeros(size(map));
ind_newbound=sub2ind(size(map),new_boundary(:,1),new_boundary(:,2));
newbound(ind_newbound)=1;
Boundary=ind_newbound;
boundarymap=newbound;
% figure;
% imshow(newbound);
% axis on
% xlabel('x');
% ylabel('y');
% title('boundary without zigzag');
% axis off
end %function

