%----------------Gao Fengyi-----------%
% main want to test the formula in the paper R(x1,y1)R(x2,y2)<p,q><0 ���ҵ�0��
% _test ��ʾ����δ��������������
% objmap ���� 0��ʾ���� 1��ʾǰ��
function [ R1,R2,points1,points2,points1_test,points2_test] = Test_R_Sign( K,P,fx,fy,fxx,fxy,fyy,fxxx,fyyy,fxxy,fxyy,H,W ,objmap)
    points1=[];
    points2=[];
    points1_test=[];
    points2_test=[];
    P_max=P(:,1,:);
    P_max=squeeze(P_max);
    P_min=P(:,2,:);
    P_min=squeeze(P_min); % 2*n
    R1=compute_R(K(:,1),P_max',fx,fy,fxx,fxy,fyy,fxxx,fyyy,fxxy,fxyy);
   
    R2=compute_R(K(:,2),P_min',fx,fy,fxx,fxy,fyy,fxxx,fyyy,fxxy,fxyy);
    disp('~~~test sign!~~~');
    for i=1:H-1
        for j=2:W  % ����ע�����б�� ע�⵽��������������б 
            
            ind1=sub2ind([H,W],i,j);
            ind2=sub2ind([H,W],i,j-1);
          %  ind3=sub2ind([H,W],i+1,j-1);
            ind4=sub2ind([H,W],i+1,j);
            sub1=[i,j];
            sub2=[i,j-1];
         %   sub3=[i+1,j-1];
            sub4=[i+1,j];
           
            p1_max=P_max(:,ind1);
            p2_max=P_max(:,ind2);
         %   p3_max=P_max(:,ind3);
            p4_max=P_max(:,ind4);
            p1_min=P_min(:,ind1);
            p2_min=P_min(:,ind2);
         %   p3_min=P_min(:,ind3);
            p4_min=P_min(:,ind4);
            p12=[];q12=[];
            if objmap(sub1(1),sub1(2))==1 && objmap(sub2(1),sub2(2))==1
                  s12 = R1(ind1)*R1(ind2)*(p1_max'*p2_max);
                  if s12<0
                       cor=[sub1;sub2];
                       r=[R1(ind1),R1(ind2)];
                       p12=compute_ridgepoint(cor,r) ;
                   else
                       p12=[];
                  end
                   t12 = R2(ind1)*R2(ind2)*(p1_max'*p2_max);
                    if t12<0
                       cor=[sub1;sub2];
                       r=[R2(ind1),R2(ind2)];
                       q12=compute_ridgepoint(cor,r) ;
                   else
                       q12=[];
                    end
                   
            end
            
             p13=[]; q13=[]; % ���ﲻ����б�� ������������һ���յĳ�ʼֵ
         %   if objmap(sub1(1),sub1(2))==1 && objmap(sub3(1),sub3(2))==1
             %     s13 = R1(ind1)*R1(ind3)*(p1_max'*p3_max);
             %               if s13<0
                %                cor=[sub1;sub3];
                %                r=[R1(ind1),R1(ind3)];
                %                p13=compute_ridgepoint(cor,r) ;
                %            else
                %                p13=[];
                %            end
             %    t13 = R2(ind1)*R2(ind3)*(p1_max'*p3_max);
                            
        %            if t13<0
        %                cor=[sub1;sub3];
        %                r=[R2(ind1),R2(ind3)];
        %                q13=compute_ridgepoint(cor,r) ;
        %            else
        %                q13=[];
        %            end
        %    end
            p14=[];q14=[];
            if objmap(sub1(1),sub1(2))==1 && objmap(sub4(1),sub4(2))==1
                 s14 = R1(ind1)*R1(ind4)*(p1_max'*p4_max);
                 if s14<0
                       cor=[sub1;sub4];
                       r=[R1(ind1),R1(ind4)];
                       p14=compute_ridgepoint(cor,r) ;
                  else
                       p14=[];
                 end
                 
                 t14 = R2(ind1)*R2(ind4)*(p1_max'*p4_max); 
                 if t14<0
                   cor=[sub1;sub4];
                   r=[R2(ind1),R2(ind4)];
                   q14=compute_ridgepoint(cor,r) ;
                 else
                   q14=[];
                 end
               
            end
                
           points1=[points1;p12;p13;p14]; 
           points2=[points2;q12;q13;q14];
           
           u12=R1(ind1)*R1(ind2);
           u14=R1(ind1)*R1(ind4);
            if u12<0
                 cor=[sub1;sub2];
                 r=[R1(ind1),R1(ind2)];
                 o12=compute_ridgepoint(cor,r);
            else
                o12=[];
            end
            
            if u14<0
                cor=[sub1;sub4];
                r=[R1(ind1),R1(ind4)];
                o14=compute_ridgepoint(cor,r);
            else
                o14=[];
            end
            points1_test=[points1_test;o12;o14];
            
           v12=R2(ind1)*R2(ind2);
           v14=R2(ind1)*R2(ind4);
            if v12<0
                 cor=[sub1;sub2];
                 r=[R2(ind1),R2(ind2)];
                 w12=compute_ridgepoint(cor,r);
            else
                w12=[];
            end
            
            if v14<0
                cor=[sub1;sub4];
                r=[R2(ind1),R2(ind4)];
                w14=compute_ridgepoint(cor,r);
            else
                w14=[];
            end
            points2_test=[points2_test;w12;w14];
        end
    end


end


function R=compute_R(K,P,fx,fy,fxx,fxy,fyy,fxxx,fyyy,fxxy,fxyy)
% P ������� n*2 ��
% p1=P_two(1,:);
% p2=P_two(2,:);

p1=P(:,1);
p2=P(:,2);
t1=p1.^3;
t2=(p1.^2).*p2;
t3=p1.*(p2.^2);
t4=p2.^3;
t5=p1.^2;
t6=p1.*p2;
t7=p2.^2;
t8=p1;
t9=p2;

R=(t1.*fxxx+(3*t2).*fxxy+(3*t3).*fxyy+t4.*fyyy)-3*sqrt(ones(size(fx))...
   + fx.*fx + fy.*fy).* (t5.*fxx+(2*t6).*fxy + t7.*fyy) .*( t8.*fx+t9 .*fy ).*K ;

end

function point=compute_ridgepoint(cor,R) 
% ��������ʦ˵�ķֱ�����0��

% if(R(1)*R(2)<0)
    rate=abs(R(1))./abs(R(1)-R(2));
    if ( R(1)>0 && R(2)>0) ||(R(1)<0 && R(2)<0 ) 
        rate=0.5;
    end
    a=[cor(1,:),R(1)];
    b=[cor(2,:),R(2)];
    ab=b-a;
    point=rate*ab+a;
% end
%    if point(1)>400 || point(2)>300
%        disp('d ');
%    end

end