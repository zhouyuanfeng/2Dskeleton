function [ points ] = local_maximum( map )
% map ��ɢͼ
[h,w]=size(map);
% 
% dy=diff(map);
% dy=[zeros(1,w);dy];
% 
% dx=diff(map,1,2);
% dx=[zeros(h,1),dx];

% �򵥵��ж����������İ������ڵĵ� ������С
direction=[-1,0;-1,-1;0,-1;1,-1;1,0;1,1;0,1;-1,1];
points=[];

for i=2:h-1
    for j=2:w-1
        new_form=repmat([i,j],[size(direction,1),1]);
        new_sub=new_form+direction;
        new_ind=sub2ind(size(map),new_sub(:,1),new_sub(:,2));
        record=find( map(new_ind)<map(i,j) ); % <=
        if size(record,1)==8
            points=[points;[i,j]];
        end
    end
end


end

