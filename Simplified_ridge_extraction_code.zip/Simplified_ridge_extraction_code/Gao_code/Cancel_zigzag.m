function [ boundary_no_zigzag ] = Cancel_zigzag( boundary ,boundarymap)
% boundary denotes the boundary we get from 4 neighbors search or 8
% neighbors search
% boundarymap boundary is 1  other area is 0
% boundary_no_zigzag denotes the boundary without zigzag
% up_right=[-1,0;0,1];
% up_left=[-1,0;0,-1];
% down_right=[1,0;0,1];
% down_left=[1,0;0,-1];
zigzag_direct=[-1,0,0,1;-1,0,0,-1;1,0,0,1;1,0,0,-1];
% new_boundary=boundary;
remove_b=[];
[row,col]=size(boundarymap);
bound_v=[];
for i=1:size(boundary,1)
  % disp(i);
  if boundary(i,1)==1||boundary(i,1)==row||boundary(i,2)==1||boundary(i,2)==col
      bound_v=boundary(i,:); %�߽��
  else
    for ii=1:4
        
    cur1=[boundary(i,1)+zigzag_direct(ii,1),boundary(i,2)+zigzag_direct(ii,2)];
   % disp(cur1);
    cur2=[boundary(i,1)+zigzag_direct(ii,3),boundary(i,2)+zigzag_direct(ii,4)];
        if boundarymap(cur1(1),cur1(2))==1 && boundarymap(cur2(1),cur2(2))==1
            %new_boundary(i,:)=[];
            remove_b=[remove_b;i];
            boundarymap(boundary(i,1),boundary(i,2))=0; %����һ�±߽�ͼ
            break;
        end
    end
  end
end
for ij=length(remove_b):-1:1
   boundary(remove_b(ij),:)=[]; 
end
%��1-length(remove_b)�Ļ� ��Ϊ�ÿջᵹ��λ�ñ仯 ��������
boundary_no_zigzag=[boundary;bound_v];

end

