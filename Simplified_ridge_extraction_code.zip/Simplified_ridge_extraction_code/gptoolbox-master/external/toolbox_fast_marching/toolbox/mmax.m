function m = mmax(A)

% mmax - maximum entry from a matrix.
%
%   m = mmax(A)
%
%   Copyright (c) 2004 Gabriel Peyr�

m = max(A(:));