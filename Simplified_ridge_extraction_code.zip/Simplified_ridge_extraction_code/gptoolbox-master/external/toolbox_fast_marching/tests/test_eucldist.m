% test for euclidean distance

M = load_image('disk', 128);
M = logical(M);
[D,L] = eucdist2(M);